const Tag_card = ({name}) => {
  return (
    <div className="tagContainer">
        {name}
    </div>
  )
}

export default Tag_card